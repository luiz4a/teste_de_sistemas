package example;


public class Calculadora{
public int soma(int x, int y){
return x+y;}


public int subtracao(int x, int y){
return x-y;
}
}