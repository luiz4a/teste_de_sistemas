package example.demo;

import java.util.Scanner;

import example.Calculadora;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculadora calc = new Calculadora();

        System.out.print("Digite o primeiro número: ");
        int num1 = scanner.nextInt();

        System.out.print("Digite o segundo número: ");
        int num2 = scanner.nextInt();

        int resultadoSoma = calc.soma(num1, num2);
        int resultadoSub = calc.subtracao(num1, num2);

        System.out.println("Resultado da soma: " + resultadoSoma);
        System.out.println("Resultado da subtração: " + resultadoSub);

        scanner.close();
    }
}
