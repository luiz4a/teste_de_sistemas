import org.junit.jupiter.api.Test;

import br.com.example.Calculadora;

public class Calculadoratest {
    @Test 
    public void somaDoisNumeros(){
        Calculadora calculadora = new Calculadora();
        int soma = caloculadora.soma(2,0);
        System.out.println(soma);
         assertEquals(2,soma);
    }

}